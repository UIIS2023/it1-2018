package geometry;

public interface Moveable {
	
	void moveBy(int byX,int byY);
}
